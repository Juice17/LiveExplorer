var LE = {};

$(document).ready(function(){
	LE = new LiveExplorer();
});